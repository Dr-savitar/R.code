#' Computing a Series of Logistic Regression Models
#' @description Compute a series of logistic regression models
#' for multi-classification based on OvR.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels.
#' @param Alphas Regularization parameters for l2 penalty of each Logistic Regression Model.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @param solver Numerical solver to use, including "gd", "nestrov" and "newton".
#' @param step.size Step size.
#' @param strategy Strategy adopted to choose step size in each iteration, including "fixed" and "backtrack".
#' @param backtrack.alpha Alpha for backtracking line search.
#' @param backtrack.beta Beta for backtracking line search.
#' @param max.iter Maximum number of iterations for the solver.
#' @param tol Stopping criterion.
#' @param random.state The seed of the pseudo random number generator to use when initializing parameters of Logistic Regression model.
#' @return \item{models_info}{Each element of list is composed of three components as follows:
#' coefficient of the features updated by newton method,
#' intercept (a.k.a. bias) updated bu newton method,
#' actual number of iteration.}
#' @author Haoxuan WANG
#' @examples ## fit a series of logistic regression models to a simple example
#' data("hayes-roth")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' lr_models <- multi.logistic_regression.fit(
#' X = X, y = y, AlphaS = c(0.1, 0.1, 0.1), solver = "newton",
#' strategy = "backtrack")
#' @export

"multi.logistic_regression.fit" <-
  function(X, y, AlphaS, sample.weight=NA,
           solver="nestrov", step.size=1, strategy="fixed",
           backtrack.alpha=0.3, backtrack.beta=0.5,
           max.iter=500, tol=1e-4, random.state=NA){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    n_samples <- nrow(X)
    n_features <- ncol(X)

    # source("R\\transform.y.R")
    # source("R\\binary.logistic_regression.fit.R")

    class_ <- levels(factor(data.matrix(y)))
    n_class <- length(class_)
    models_info <- list()

    # set the seed only if it's provided
    if (!is.na(random.state)){
      set.seed(random.state)
    }

    i = 1
    while (i <= n_class) {
      positive.label <- class_[i]
      y_i <- transform.y(y = y, positive.label = positive.label)

      results <- binary.logistic_regression.fit(
        X = X, y = y_i, positive.label = 1, alpha = AlphaS[i],
        sample.weight = sample.weight, solver = solver, step.size = step.size,
        strategy = strategy, backtrack.alpha = backtrack.alpha, backtrack.beta = backtrack.beta,
        max.iter = max.iter, tol = tol, random.state = random.state)
      models_info <- c(models_info, list(results))
      i <- i + 1
    }

    return(models_info)
  }
