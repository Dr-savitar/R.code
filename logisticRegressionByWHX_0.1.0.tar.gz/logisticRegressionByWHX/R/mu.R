#' Computing Probability of Positive Class
#' @description Computeing 1 / (1 + exp(- (w %*% x + b))
#' (a.k.a the probability of belonging to the positive class).
#' @param w Coefficient vector.
#' @param b Intercept.
#' @param X Training data, each row of which represents an observation.
#' @return \item{mu}{Matrix consisting of 1 / (1 + exp(- (w %*% x + b)) for each observation.}
#' @author Haoxuan WANG
#' @examples
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' ## Initializing parameters of a Logistic Regression model
#' w <- matrix(rnorm(ncol(X)))
#' b <- rnorm(1)
#' mu <- mu(w = w, b = b, X = X)

"mu" <-
  function(w, b, X){


    if(is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }

    eta <- X %*% w + b
    mu <- 1 / (1 + exp(-eta))
    return (mu)
  }


