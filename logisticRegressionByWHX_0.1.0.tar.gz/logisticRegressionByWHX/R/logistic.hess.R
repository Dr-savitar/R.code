#' Computing Hessian of Logistic Regression Model
#' @description Compute the hessian of Logistic Regression Model
#' with \code{l2} penalty.
#' @param w Coefficient vector.
#' @param b Intercept.
#' @param tidy.X Tidy training data, each row of which represents an observation.
#' @param tidy.y Tidy labels.
#' @param alpha Regularization parameter for l2 penalty.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @return \item{hess}{Logistic Hessian with l2 penalty.}
#' @author Haoxuan WANG
#' @examples ## compute Hessian of a Logistic Regression Model
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' if (is.data.frame(X)){
#' X <- data.matrix(X){      # transform X into matrix
#' colnames(X) <- NULL
#' }
#' y <- transform.y(y, 1)
#' ## Initializing parameters of a Logistic Regression model
#' w <- matrix(rnorm(ncol(X)))
#' b <- rnorm(1)
#' hess <- logistic.hess(w = w, b = b, tidy.X = X, tidy.y = y, alpha = 0.1)

"logistic.hess" <-
  function(w, b, tidy.X, tidy.y,
           alpha, sample.weight=NA){

    n_samples <- nrow(tidy.X)
    n_features <- ncol(tidy.X)

    if (is.na(sample.weight)){
      sample.weight <- data.matrix(rep(1, n_samples))
    }

    # Add 1 to each row of X
    X_hat <- cbind(tidy.X, data.matrix(rep(1, n_samples)))

    # source("R\\mu.R")
    S <- diag(c(mu(w, b, tidy.X) * (1 - mu(w, b, tidy.X)) * sample.weight))
    hess <- t(X_hat) %*% S %*% X_hat + alpha * diag(c(rep(1, n_features), 0))

    return (hess)
  }


