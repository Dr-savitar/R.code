#' Computing Logistic Loss
#' @description Compute the logistic loss with \code{l2} penalty.
#' @param w Coefficient vector.
#' @param b Intercept.
#' @param tidy.X Tidy training data, each row of which represents an observation.
#' @param tidy.y Tidy labels.
#' @param alpha Regularization parameter for l2 penalty.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @return \item{loss}{Logistic loss with l2 penalty.}
#' @author Haoxuan WANG
#' @examples ## compute the loss of a Logistic Regression Model
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' y <- transform.y(y, 1)
#' ## Initializing parameters of a Logistic Regression model
#' w <- matrix(rnorm(ncol(X)))
#' b <- rnorm(1)
#' loss <- logistic.loss(w = w, b = b, tidy.X = X, tidy.y = y, alpha = 0.1)

"logistic.loss" <-
  function(w, b, tidy.X, tidy.y,
           alpha, sample.weight=NA){

    n_samples <- nrow(tidy.X)
    n_features <- ncol(tidy.X)

    if (is.na(sample.weight)){
      sample.weight <- data.matrix(rep(1, n_samples))
    }

    eta <- tidy.X %*% w + b
    # Logistic loss is the negative of the log of the logistic function.
    loss <- sum(sample.weight * (-tidy.y * eta + log(1 + exp(eta)))) + 0.5 * alpha * sum(w * w)

    return (loss)
  }


