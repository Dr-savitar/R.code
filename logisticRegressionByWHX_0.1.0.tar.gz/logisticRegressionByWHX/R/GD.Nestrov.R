#' Accelerated Gradient Descent Method
#' @description Updating parameters of a Logistic Regression Model with
#' accelerated gradient descent method.
#' @param w Coefficient vector in the current iteration.
#' @param b Intercept in the current iteration.
#' @param w_prev coefficient vector in the previous iteration.
#' @param b_prev Intercept in the previous iteration.
#' @param iter Iterations used for adjusting the weight of momentum term.
#' @param X Training data, each row of which represents an observation.
#' @param y Label.
#' @param positive.label The positive class preassigned.
#' @param alpha Regularization parameter for l2 penalty.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @param step.size Step size.
#' @param strategy Strategy adopted to choose step size in each iteration, including "fixed" and "backtrack".
#' @param backtrack.alpha Alpha for backtracking line search.
#' @param backtrack.beta Beta for backtracking line search.
#' @return \item{coef_}{Coefficient of the features updated by accelerated gradient descent method..}
#' @return \item{intercept_}{Intercept (a.k.a. bias) updated by accelerated gradient descent method..}
#' @author Haoxuan WANG

"GD.Nestrov" <-
  function(w, b, w_prev, b_prev, iter,
           X, y, positive.label, alpha, sample.weight=NA,
           step.size=1, strategy="fixed",
           backtrack.alpha=0.3, backtrack.beta=0.5){

    if(is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    # source("R\\transform.y.R")
    y <- transform.y(y, positive.label)

    n_samples <- nrow(X)
    n_features <- ncol(X)

    # Rewrite (w; b)^T as a column vector beta
    beta <- rbind(w, matrix(b))
    beta_prev <- rbind(w_prev, matrix(b_prev))

    v <- beta + (iter - 1) / (iter + 2) * (beta - beta_prev)

    # source("R\\logistic.loss.R")
    # source("R\\logistic.grad.R")

    loss <- logistic.loss(w = w, b = b, tidy.X = X, tidy.y = y,
                          alpha = alpha, sample.weight = sample.weight)
    grad <- logistic.grad(w = w, b = b, tidy.X = X, tidy.y = y,
                          alpha = alpha, sample.weight = sample.weight)
    v.grad <- logistic.grad(w = data.matrix(v[1:nrow(v) - 1]),
                            b = v[nrow(v)],
                            tidy.X = X, tidy.y = y,
                            alpha = alpha, sample.weight = sample.weight)
    d_beta <- -v.grad
    dw <- data.matrix(d_beta[1:nrow(d_beta) - 1])
    db <- d_beta[nrow(d_beta)]

    if(strategy == "fixed"){
      beta <- beta + step.size * d_beta
    }
    else if(strategy == "backtrack"){
      t <- 1
      temp <- logistic.loss(w = w + t * dw, b = b + t * db,
                            tidy.X = X, tidy.y = y,
                            alpha = alpha, sample.weight = sample.weight)
      while (temp > loss + backtrack.alpha * t * t(grad) %*% d_beta){
        t <- t * backtrack.beta
        temp <- logistic.loss(w = w + t * dw, b = b + t * db,
                              tidy.X = X, tidy.y = y,
                              alpha = alpha, sample.weight = sample.weight)
      }
      beta <- beta + t * d_beta
    }
    else{
      print("Search Algorithm Error!")
      return(NA)
    }

    coef_ <- beta[1:nrow(beta) - 1]
    intercept_ <- beta[nrow(beta)]

    return(list(coef_=data.matrix(coef_),
                intercept_=data.matrix(intercept_)[1]))
  }


