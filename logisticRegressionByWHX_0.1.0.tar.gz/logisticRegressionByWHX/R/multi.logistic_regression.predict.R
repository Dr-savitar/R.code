#' Predicting Each Observation's Class (Multi-Class)
#' @description Predict each observation's class in the case of multi-classification.
#' @param models A series of Logistic Regresion Models computed by function multi.logistic_regression.fit.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels.
#' @return \item{prob_pred}{Each observation's probabilities belonging to each class.}
#' @return \item{pred}{Each observation's class predicted by the models.}
#' @author Haoxuan WANG
#' @examples ## predict each observation's class
#' data("hayes-roth")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' lr_models <- multi.logistic_regression.fit(
#' X = X, y = y, AlphaS = c(0.1, 0.1, 0.1), solver = "newton",
#' strategy = "backtrack")
#' y_predict <- multi.logistic_regression.predict(
#' models = lr_models, X = X, y = y)$pred
#' @export

"multi.logistic_regression.predict" <-
  function(models, X, y){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    n_samples <- nrow(X)
    n_features <- ncol(X)

    class_ <- levels(factor(data.matrix(y)))
    n_class <- length(class_)

    # source("R\\mu.R")
    prob_pred <- matrix(rep(0, n_class * n_samples), byrow = TRUE, ncol = n_class)
    i = 1
    while (i <= n_class){
      w_i <- models[[i]]$coef_
      b_i <- models[[i]]$intercept_

      prob_i <- mu(w_i, b_i, X)
      prob_pred[, i] <- prob_i

      i <- i + 1
    }

    j = 1
    pred <- matrix(data = rep(0, n_samples))
    while (j <= n_samples) {
      id <- seq(1:n_class)[prob_pred[j, ] == max(prob_pred[j, ])]
      pred[j] <- class_[id]

      j <- j + 1
    }

    return(list(prob_pred=prob_pred,
                pred=pred))
  }
