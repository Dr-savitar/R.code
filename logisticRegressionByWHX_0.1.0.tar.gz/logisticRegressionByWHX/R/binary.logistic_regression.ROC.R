#' Computeing AUC of a Logistic Regression Model
#' @description Computes auc of a Logistic Regression Model and plot ROC curve if necessary.
#' @param w Coefficient vector.
#' @param b Intercept
#' @param positive.label The positive class preassigned.
#' @param ifplot Option letting users to decide whether to plot ROC curve.
#' @return \item{auc}{AUC of a Logistic Regression Model.}
#' @author Haoxuan WANG

"binary.logistic_regression.ROC" <-
  function(w, b, X, y, positive.label, ifplot=FALSE){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    # source("R\\transform.y.R")
    y <- transform.y(y, positive.label)

    n_samples <- nrow(X)
    n_features <- ncol(X)

    # source("R\\mu.R")
    prob <- mu(w = w, b = b, X = X)

    library(pROC)
    modelroc <- roc(response = y, predictor = as.vector(prob))
    if (ifplot){
      plot(modelroc, print.auc=TRUE, auc.polygon=TRUE, grid=c(0.1, 0.2),
           grid.col=c("green", "red"), max.auc.polygon=TRUE,
           auc.polygon.col="skyblue", print.thres=TRUE)
    }
    auc <- modelroc$auc

    return(auc)
  }
