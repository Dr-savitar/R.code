#' Transforming Object y into matrix
#' @description Checks whether y is presented in the form of 0 or 1.
#'      If not, then denote positive class as 1 and negative class as 0.
#'      This function is designed for two-class classification.
#' @param y Labels.
#' @param positive.label The positive class preassigned.
#' @return binary_y Labels transformed into 1 or 0.
#' @author Haoxuan WANG
#' @examples
#' data("appendicitis")
#' y <- data[ncol(data)]
#' tidy_y <- transform.y(y, 1)

"transform.y" <-
  function(y, positive.label){

    if (is.data.frame(y)){
      y <- data.matrix(y)      # transform y into matrix
    }
    positive.position <- y == positive.label
    negative.position <- y != positive.label

    binary_y <- data.matrix(rep(0, length(y)))
    if (sum(positive.position) != 0){
      binary_y[positive.position] <- 1
    }

    colnames(binary_y) <- NULL

    return (binary_y)
  }

