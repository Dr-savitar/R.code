#' Newton Method
#' @description Updating parameters of a Logistic Regression Model with
#' gradient descent method.
#' @param w Coefficient vector.
#' @param b Intercept.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels
#' @param positive.label The positive class preassigned.
#' @param alpha Regularization parameter for l2 penalty.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @param step.size Step size.
#' @param strategy Strategy adopted to choose step size in each iteration, including "fixed" and "backtrack".
#' @param backtrack.alpha Alpha for backtracking line search.
#' @param backtrack.beta Beta for backtracking line search.
#' @return \item{coef_}{Coefficient of the features updated by newton method.}
#' @return \item{intercept_}{Intercept (a.k.a. bias) updated by newton method.}
#' @return \item{lambda_square}{Newton reduction at this point.}
#' @author Haoxuan WANG
#' @examples ## update parameters with newton method
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' ## Initializing parameters of a Logistic Regression model
#' w <- matrix(rnorm(ncol(X)))
#' b <- rnorm(1)
#' updated_para <- newton(w = w, b = b, X = X, y = y,
#' positive.label = 1, alpha = 0.1, strategy = "backtrack")
#' w <- updated_para$coef_
#' b <- updated_para$intercept_
#' lambda_square <- updated_para$lambda_square

"newton" <-
  function(w, b, X, y, positive.label, alpha, sample.weight=NA,
           step.size=1, strategy="fixed",
           backtrack.alpha=0.3, backtrack.beta=0.5){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    # source("R\\transform.y.R")
    y <- transform.y(y, positive.label)

    n_samples <- nrow(X)
    n_features <- ncol(X)

    # source("R\\logistic.loss.R")
    # source("R\\logistic.grad.R")
    # source("R\\logistic.hess.R")

    loss <- logistic.loss(w = w, b = b, tidy.X = X, tidy.y = y,
                          alpha = alpha, sample.weight = sample.weight)
    grad <- logistic.grad(w = w, b = b, tidy.X = X, tidy.y = y,
                          alpha = alpha, sample.weight = sample.weight)
    hess <- logistic.hess(w = w, b = b, tidy.X = X, tidy.y = y,
                          alpha = alpha, sample.weight = sample.weight)

    # Rewrite (w; b)^T as a column vector beta
    beta <- rbind(w, matrix(b))
    d_beta <- - solve(hess) %*% grad
    dw <- data.matrix(d_beta[1:nrow(d_beta) - 1])
    db <- d_beta[nrow(d_beta)]
    lambda.square <- t(grad) %*% solve(hess) %*% grad      # newton reduction

    if (strategy == "fixed"){
      beta <- beta + step.size * d_beta
    }
    else if (strategy == "backtrack"){
      t <- 1
      temp <- logistic.loss(w = w + t * dw, b = b + t * db,
                            tidy.X = X, tidy.y = y,
                            alpha = alpha, sample.weight = sample.weight)
      while (temp > loss + backtrack.alpha * t * t(grad) %*% d_beta){
        t <- t * backtrack.beta
        temp <- logistic.loss(w = w + t * dw, b = b + t * db,
                              tidy.X = X, tidy.y = y,
                              alpha = alpha, sample.weight = sample.weight)
      }
      beta <- beta + t * d_beta
    }
    else{
      print("Search Algorithm Error!")
      return(NA)
    }

    coef_ <- beta[1:nrow(beta) - 1]
    intercept_ <- beta[nrow(beta)]

    return (list(coef_=data.matrix(coef_),
                 intercept_=data.matrix(intercept_)[1],
                 lambda_square=lambda.square))
  }


