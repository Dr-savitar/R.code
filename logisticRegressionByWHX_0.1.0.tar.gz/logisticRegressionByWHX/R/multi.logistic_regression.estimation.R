#'Estimating a Series of Logistic Regression Models
#' @description Estimate a series of logistic regression models
#'      for multi-classification based on OvR.
#' @param models A series of Logistic Regresion Models computed by function multi.logistic_regression.fit.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels.
#' @return \item{acc}{Accuracy of Model (based on OvR).}
#' @author Haoxuan WANG
#' @examples ## estimate the model
#' data("hayes-roth")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' lr_models <- multi.logistic_regression.fit(
#' X = X, y = y, AlphaS = c(0.1, 0.1, 0.1), solver = "newton",
#' strategy = "backtrack")
#' acc <- multi.logistic_regression.estimation(
#' models = lr_models, X = X, y = y)
#' @export

"multi.logistic_regression.estimation" <-
  function(models, X, y){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    n_samples <- nrow(X)
    n_features <- ncol(X)

    # source("R\\multi.logistic_regression.predict.R")
    y_predict <- multi.logistic_regression.predict(models = models, X = X, y = y)$pred

    # calculate accuracy of model
    acc <- sum(y_predict == y) / n_samples

    return(acc)
  }
