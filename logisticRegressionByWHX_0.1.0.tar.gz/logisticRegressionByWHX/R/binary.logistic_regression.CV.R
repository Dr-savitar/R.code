#' Selecting Optimal Alpha Parameter
#' @description Select the optimal alpha parameter with cross-validation and compute a Logistic Regression model for binary classification.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels.
#' @param positive.label The positive class preassigned.
#' @param alpha_gird The grid of regularization parameter for l2 penalty. Each of the values in alpha_grid describes regularization strength.
#' @param k Number of copies of data needed to be divided.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @param solver Numerical solver to use, including "gd", "nestrov" and "newton".
#' @param step.size Step size.
#' @param strategy Strategy adopted to choose step size in each iteration, including "fixed" and "backtrack".
#' @param backtrack.alpha Alpha for backtracking line search.
#' @param backtrack.beta Beta for backtracking line search.
#' @param max.iter Maximum number of iterations for the solver.
#' @param tol Stopping criterion.
#' @param random.state The seed of the pseudo random number generator to use when initializing parameters of Logistic Regression model.
#' @param ifprint Option letting users to decide whether to print details of iterations or not.
#' @return \item{optimal_alpha}{The optimal alpha parameter selected by cross validation.}
#' @return \item{coef_}{Coefficient of the features returned by the function.}
#' @return \item{intercept_}{Intercept (a.k.a. bias) returned by the function.}
#' @return \item{n_iter}{Actual number of iteration.}
#' @author Haoxuan WANG
#' @examples ## fit a logistic regression model to a simple example
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' results <- binary.logistic_regression.CV(X = X, y = y, positive.label = 1,
#' alpha_grid = c(0.1, 1), solver = "newton", strategy = "backtrack")
#' ## optimal alpha
#' print(results$optimal_alpha)
#' ## coefficient
#' print(results$coef_)
#' ## intercept
#' print(results$intercept_)
#' @export

"binary.logistic_regression.CV" <-
  function(X, y, positive.label, alpha_grid, k=3, sample.weight=NA,
           solver="nestrov", step.size=1, strategy="fixed",
           backtrack.alpha=0.3, backtrack.beta=0.5,
           max.iter=500, tol=1e-4, random.state=NA, ifprint=FALSE){

    class_ <- levels(factor(y))
    n_class <- length(class_)
    print(n_class)
    if (n_class > 2){
      print("The number of categories Error!")
      return(NA)
    }

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    # source("R\\transform.y.R")
    y <- transform.y(y, positive.label)
    n_samples <- nrow(X)
    n_features <- ncol(X)

    # set the seed only if it's provided
    if (!is.na(random.state)){
      set.seed(random.state)
    }

    # source("R\\binary.logistic_regression.fit.R")
    # source("R\\binary.logistic_regression.estimation.R")

    # spilt data into k folds
    library(caret)
    folds <- createFolds(y = y, k = k)

    best_score <- 0
    for (alpha in alpha_grid) {
      scores <- rep(0, k)
      for (i in 1:k) {
        X_train_i <- X[-folds[[i]], ]
        y_train_i <- y[-folds[[i]], ]

        X_valid_i <- X[folds[[i]],]
        y_valid_i <- y[folds[[i]],]

        class_i <- levels(factor(y_valid_i))
        n_class_i <- length(class_i)
        if (n_class_i < 2){
          scores[i] <- NA
          next
        }

        lr_model <- binary.logistic_regression.fit(X = X_train_i, y = y_train_i,
                     positive.label = positive.label,
                     alpha = alpha, sample.weight = sample.weight,
                     solver = solver, step.size = step.size, strategy = strategy,
                     backtrack.alpha = backtrack.alpha, backtrack.beta = backtrack.beta,
                     max.iter = max.iter, tol = tol, random.state = random.state)
        w <- lr_model$coef_
        b <- lr_model$intercept_
        auc <- binary.logistic_regression.estimation(w = w, b = b,
                     X = X_valid_i, y = y_valid_i,
                     positive.label = positive.label)$auc
        scores[i] <- auc
      }
      score <- mean(scores, na.rm = TRUE)
      if (score > best_score){
        best_score <- score
        optimal_alpha <- alpha
      }
    }

    results <- binary.logistic_regression.fit(X = X, y = y, positive.label = positive.label,
                     alpha = optimal_alpha, sample.weight = sample.weight,
                     solver = solver, step.size = step.size, strategy = strategy,
                     backtrack.alpha = backtrack.alpha, backtrack.beta = backtrack.beta,
                     max.iter = max.iter, tol = tol, random.state = random.state,
                     ifprint = ifprint)

    return(list(optimal_alpha=optimal_alpha,
                coef_=results$coef_,
                intercept_=results$intercept_,
                n_iter=results$n_iter))
  }
