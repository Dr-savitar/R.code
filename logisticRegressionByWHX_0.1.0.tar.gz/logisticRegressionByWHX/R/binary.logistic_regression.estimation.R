#' Estimating a Logistic Regression Model
#' @description Estimate a Logistic Regression Model for binary classification.
#' @param w Coefficient vector.
#' @param b Intercept.
#' @param X Training data, each row of which represents an observation.
#' @param y Label.
#' @param positive.label The positive class preassigned.
#' @param threshold Probability to be judged as the positive.
#' @param ifplot Option letting users to decide whether to plot ROC curve.
#' @return \item{acc}{Accuracy of Logistic Regression Model.}
#' @return \item{precision}{Precision of Logistic Regression Model.}
#' @return \item{recall}{Recall of Logistic Regression Model.}
#' @return \item{f1}{F1 of Logistic Regression Model.}
#' @return \item{auc}{AUC of Logistic Regression Model.}
#' @author Haoxuan WANG
#' @examples ## estimate a logistic regression model to a simple example
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' lr_model <- binary.logistic_regression.fit(X = X, y = y, positive.label = 1,
#' alpha = 0.1, solver = "newton", strategy = "backtrack")
#' w <- lr_model$coef_
#' b <- lr_model$intercept_
#' estimates <- binary.logistic_regression.estimation(
#' w = w, b = b, X = X, y = y, positive.label = 1)
#' ## auc
#' cat("AUC of Logistic Regression Model:", estimates$auc)
#' @export

"binary.logistic_regression.estimation" <-
  function(w, b, X, y, positive.label, threshold=0.5, ifplot=FALSE){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    n_samples <- nrow(X)
    n_features <- ncol(X)

    # source("R\\binary.logistic_regression.predict.R")
    y_predict <- binary.logistic_regression.predict(w = w, b = b,
                                                    X = X, y = y,
                                                    positive.label = positive.label,
                                                    threshold = threshold)$pred

    # calculate accuracy of model
    acc <- sum(y_predict == y) / n_samples

    # calculate precision and recall of model
    tp <- sum(y_predict == positive.label & y == positive.label)
    fn <- sum(y_predict != positive.label & y == positive.label)
    fp <- sum(y_predict == positive.label & y != positive.label)
    tn <- sum(y_predict != positive.label & y != positive.label)

    precision <- tp / (tp + fp)
    recall <- tp / (tp + fn)

    f1 <- (2 * precision * recall) / (precision + recall)

    # calculate auc and plot ROC curve
    # source("R\\binary.logistic_regression.ROC.R")
    auc <- binary.logistic_regression.ROC(w = w, b = b, X = X, y = y,
                                          positive.label = positive.label,
                                          ifplot = ifplot)

    return(list(acc=acc,
                precision=precision, recall=recall, f1=f1,
                auc=auc+1-1))
  }
