#' Predicting Each Observation's Class
#' @description Predict each observation's class.
#' @param w Coefficient vector.
#' @param b Intercept.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels.
#' @param positive.label The positive class preassigned.
#' @param threshold Probability to be judged as the positive.
#' @return \item{binary_pred}{Class of each observation represented by 0 or 1.}
#' @return \item{pred}{Class of each observation.}
#' @author Haoxuan WANG
#' @examples ## fit a logistic regression model to a simple example
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' lr_model <- binary.logistic_regression.fit(X = X, y = y, positive.label = 1,
#' alpha_grid = c(0.1, 1), solver = "newton", strategy = "backtrack")
#' ## predict each observation's class
#' w <- lr_model$coef_
#' b <- lr_model$intercept_
#' y_predict <- binary.logistic_regression.predict(
#' w = w, b = b, X = X, y = y, positive.label = 1)
#' @export

"binary.logistic_regression.predict" <-
  function(w, b, X, y, positive.label, threshold=0.5){

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    n_samples <- nrow(X)
    n_features <- ncol(X)

    # source("R\\mu.R")
    prob <- mu(w = w, b = b, X = X)

    class_ <- levels(factor(data.matrix(y)))
    binary_pred <- data.matrix(rep(1, n_samples))
    pred <- data.matrix(rep(positive.label, n_samples))

    if (sum(prob < threshold)){
      binary_pred[prob < threshold] <- 0

      negative.label <- class_[class_ != positive.label]
      pred[prob < threshold] <- 0
    }

    return(list(binary_pred=binary_pred, pred=pred))
  }
