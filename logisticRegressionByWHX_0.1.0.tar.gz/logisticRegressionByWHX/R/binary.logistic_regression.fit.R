#' Computing a Logistic Regression model
#' @description Compute a Logistic Regression model for binary classification.
#' @param X Training data, each row of which represents an observation.
#' @param y Labels.
#' @param positive.label The positive class preassigned.
#' @param alpha Regularization parameter for l2 penalty.
#' @param sample.weight Matrix of weights that are assigned to individual samples. If not provided, then each sample is given unit weight.
#' @param solver Numerical solver to use, including "gd", "nestrov" and "newton".
#' @param step.size Step size.
#' @param strategy Strategy adopted to choose step size in each iteration, including "fixed" and "backtrack".
#' @param backtrack.alpha Alpha for backtracking line search.
#' @param backtrack.beta Beta for backtracking line search.
#' @param max.iter Maximum number of iterations for the solver.
#' @param tol Stopping criterion.
#' @param random.state The seed of the pseudo random number generator to use when initializing parameters of Logistic Regression model.
#' @param ifprint Option letting users to decide whether to print details of iterations or not.
#' @return \item{coef_}{Coefficient of the features returned by the function.}
#' @return \item{intercept_}{Intercept (a.k.a. bias) returned by the function.}
#' @return \item{n_iter}{Actual number of iteration.}
#' @author Haoxuan WANG
#' @examples ## fit a logistic regression model to a simple example
#' data("appendicitis")
#' X <- data[-ncol(data)]
#' y <- data[ncol(data)]
#' results <- binary.logistic_regression.fit(X = X, y = y, positive.label = 1, alpha = 0.1, solver = "newton", strategy = "backtrack")
#' ## coefficient
#' print(results$coef_)
#' ## intercept
#' print(results$intercept_)
#' @export

"binary.logistic_regression.fit" <-
  function(X, y, positive.label, alpha, sample.weight=NA,
           solver="nestrov", step.size=1, strategy="fixed",
           backtrack.alpha=0.3, backtrack.beta=0.5,
           max.iter=500, tol=1e-4, random.state=NA, ifprint=FALSE){

    class_ <- levels(factor(y))
    n_class <- length(class_)
    if (n_class > 2){
      print("The number of categories Error!")
      return(NA)
    }

    if (is.data.frame(X)){
      X <- data.matrix(X)      # transform X into matrix
      colnames(X) <- NULL
    }
    # source("R\\transform.y.R")
    y <- transform.y(y, positive.label)
    n_samples <- nrow(X)
    n_features <- ncol(X)

    # set the seed only if it's provided
    if (!is.na(random.state)){
      set.seed(random.state)
    }

    # Initializing parameters of Logistic Regression model
    coef_ <- matrix(rnorm(n_features))
    intercept_ <- rnorm(1)

    # source("R\\gradient.descent.R")
    # source("R\\newton.R")
    # source("R\\GD.Nestrov.R")

    # source("R\\logistic.loss.R")
    # source("R\\logistic.grad.R")

    ## Computes parameters of a Logistic Regression model
    i <- 1      # number of iterations
    if (solver == "gd"){
      while (i <= max.iter){
        results <- gradient.descent(w = coef_, b = intercept_, X = X, y = y,
                                    positive.label = positive.label, alpha = alpha,
                                    sample.weight = sample.weight,
                                    step.size = step.size, strategy = strategy,
                                    backtrack.alpha = backtrack.alpha,
                                    backtrack.beta = backtrack.beta)
        coef_ <- results$coef_
        intercept_ <- results$intercept_

        loss <- logistic.loss(w = coef_, b = intercept_,
                              tidy.X = X, tidy.y = y, alpha = alpha,
                              sample.weight = sample.weight)
        grad_eta <- logistic.grad(w = coef_, b = intercept_,
                                  tidy.X = X, tidy.y = y, alpha = alpha,
                                  sample.weight = sample.weight)
        grad_length <- sqrt(sum(grad_eta * grad_eta))

        if (ifprint){
          cat("Iteration:", i, "\nloss:", loss, "  grad_length:", grad_length, "\n")
        }

        if (grad_length < tol){
          n_iter <- i
          if (ifprint){
            cat("Converge!\n")
          }
          return(list(coef_=coef_,
                      intercept_=intercept_,
                      n_iter=n_iter))
        }
        i <- i + 1
      }
      return(list(coef_=coef_,
                  intercept_=intercept_,
                  n_iter=max.iter))
    }
    else if (solver == "nestrov"){
      # define parameters of the previous iteration
      coef_prev <- coef_
      intercept_prev <- intercept_

      while (i <= max.iter){
        results <- GD.Nestrov(w = coef_, b = intercept_,
                              w_prev = coef_prev, b_prev = intercept_prev,
                              iter = i - 1,
                              X = X, y = y,
                              positive.label = positive.label, alpha = alpha,
                              sample.weight = sample.weight,
                              step.size = step.size, strategy = strategy,
                              backtrack.alpha = backtrack.alpha,
                              backtrack.beta = backtrack.beta)
        coef_ <- results$coef_
        intercept_ <- results$intercept_

        loss <- logistic.loss(w = coef_, b = intercept_,
                              tidy.X = X, tidy.y = y, alpha = alpha,
                              sample.weight = sample.weight)
        grad_eta <- logistic.grad(w = coef_, b = intercept_,
                                  tidy.X = X, tidy.y = y, alpha = alpha,
                                  sample.weight = sample.weight)
        grad_length <- sqrt(sum(grad_eta * grad_eta))

        if (ifprint){
          cat("Iteration:", i, "\nloss:", loss, "  grad_length:", grad_length, "\n")
        }

        if (grad_length < tol){
          n_iter <- i
          if (ifprint){
            cat("Converge!\n")
          }
          return(list(coef_=coef_,
                      intercept_=intercept_,
                      n_iter=n_iter))
        }
        i <- i + 1
      }
      return(list(coef_=coef_,
                  intercept_=intercept_,
                  n_iter=max.iter))
    }
    else if (solver == "newton"){
      while (i <= max.iter){
        results <- newton(w = coef_, b = intercept_,
                          X = X, y = y,
                          positive.label = positive.label, alpha = alpha,
                          sample.weight = sample.weight,
                          step.size = step.size, strategy = strategy,
                          backtrack.alpha = backtrack.alpha,
                          backtrack.beta = backtrack.beta)
        coef_ <- results$coef_
        intercept_ <- results$intercept_

        loss <- logistic.loss(w = coef_, b = intercept_,
                              tidy.X = X, tidy.y = y, alpha = alpha,
                              sample.weight = sample.weight)
        lambda_square <- results$lambda_square

        if (ifprint){
          cat("Iteration:", i, "\nloss:", loss, "  newton reduction:", lambda_square, "\n")
        }

        if (lambda_square < tol){
          n_iter <- i
          if (ifprint){
            cat("Converge!\n")
          }
          return(list(coef_=coef_,
                      intercept_=intercept_,
                      n_iter=n_iter))
        }
        i <- i + 1
      }
      return(list(coef_=coef_,
                  intercept_=intercept_,
                  n_iter=max.iter))
    }
    else{
      print("Solver Error!")
      return(NA)
    }
}
